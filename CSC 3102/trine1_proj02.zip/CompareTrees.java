package comparetrees;
import java.io.*;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Scanner;
import java.util.function.Function;

/**
 * Performs insertions and searches, using the same data set,on a binary search
 * tree and an AVL tree to compare the empirically compare the performance of
 * these operations on the trees.
* @author Timothy Rine
* @since March 15, 2017
* Course: CS3102.01
* Programming Project #: 2
* Instructor: Dr. Duncan
* @see BSTree, BSTreeAPI, BSTreeException, AVLTree, AVLTreeAPI, AVLTreeException, and WordStat.java
 */
public class CompareTrees 
{
private class Node
{
  public WordStat data;
  public Node left;
  public Node right;
} 
    /**
     * @param args the command line arguments
     * @throws AVLTreeException
     * @throws BSTreeException
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws AVLTreeException, BSTreeException, java.io.IOException
    {  
       //beginning of try-catch statement
       try
       {
       //creates scanner object and reads the file with the name specified as the given command-line argument
       Scanner inFile = new Scanner(new FileReader(args[0]));  
       //beginning of while loop, continues as long as there is input from the text file
       while(inFile.hasNextLine())
       {
           //string to hold the data from the current line
           String testerfile = inFile.nextLine();
           //creates an empty avltree
           AVLTree avltree = new AVLTree();
           //inserts the data into the avltree
           avltree.insert(testerfile);
           //creates an empty bstree
           BSTree bstree = new BSTree();
           //inserts the data into the bstree
           bstree.insert(testerfile);                 
        
        //prints table 1
        System.out.printf("Table 1:Binary Search Tree [%s]\n",args[0]);
        System.out.printf("In-order Traversal\n");
        System.out.printf("===================================\n");
        System.out.printf("Word     Frequency\n");
        System.out.printf("-----------------------------------\n");   
        //sets the count variable to 0
        int count = 0;
        while(inFile.hasNext())
        {
            //creates the string word object
            String word = inFile.next();
            //converts each word into an uppercase wordstat object and sets initial frequency to 1 
            WordStat ws = new WordStat(word.toUpperCase(), 1);
            //loop continues if the word already exists in the tree
            if(avltree.inTree(ws))
            {
                avltree.retrieve(ws).updateCount(1);
                bstree.retrieve(ws).updateCount(1);
            }
            //otherwise enter this loop
            else
            {
                //insert word into avl and bstree, increment count by 1
                avltree.insert(ws);
                bstree.insert(ws);
                ws.updateCount(1);
            }
            //traverse the avl tree and apply the given function to each node visited
            avltree.traverse((w)->{
                return System.out.printf("%-10s%d%n",ws.getWord(), ws.getCount());
            });
            //print the word and its count
            Function<WordStat, PrintStream> func = w -> System.out.printf("%-10s%10d%n", w.getWord(), w.getCount());
        avltree.traverse(func);
        }
        System.out.printf("-----------------------------------\n\n");   
       }
       
       
       Scanner inFile2  = new Scanner(new FileReader(args[0]));  
       while(inFile.hasNextLine())
       {
           String testerfile = inFile2.nextLine();
           AVLTree avltree = new AVLTree<WordStat>();
           avltree.insert(testerfile);
           BSTree bstree = new BSTree<WordStat>();
           bstree.insert(testerfile);          
           
        System.out.printf("Table 2:AVL Tree [%s]\n",args[0]);
        System.out.printf("In-order Traversal\n");
        System.out.printf("===================================\n");
        System.out.printf("Word     Frequency\n");
        System.out.printf("-----------------------------------\n"); 
        int count = 0;
        while(inFile.hasNextLine())
        {
            String word = inFile.next();
            WordStat ws = new WordStat(word.toUpperCase(), count);
            if(avltree.inTree(ws))
            {
                avltree.retrieve(ws).updateCount(1);
                bstree.retrieve(ws).updateCount(1);
            }
            else
            {
                avltree.insert(ws);
                bstree.insert(ws);
                ws.updateCount(1);
            }
            avltree.traverse((w)->{
                return System.out.printf("%-10s%d%n",ws.getWord(), ws.getCount());
            });
        }
        System.out.printf("-----------------------------------\n\n");   
       } 
       
       
       Scanner inFile3  = new Scanner(new FileReader(args[0]));  
       while(inFile.hasNext())
       {
           String testerfile = inFile3.nextLine();
           AVLTree avltree = new AVLTree<WordStat>();
           avltree.insert(testerfile);
           BSTree bstree = new BSTree<WordStat>();
           bstree.insert(testerfile);          
           
        System.out.printf("Table 3:Binary Search Tree [%s]\n",args[0]);
        System.out.printf("In-order Traversal\n");
        System.out.printf("===================================\n");
        System.out.printf("Word     Frequency\n");
        System.out.printf("-----------------------------------\n"); 
        int count = 0;
        while(inFile.hasNext())
        {
            String word = inFile.next();
            WordStat ws = new WordStat(word.toUpperCase(), count);
            if(avltree.inTree(ws))
            {
                avltree.retrieve(ws).updateCount(1);
                bstree.retrieve(ws).updateCount(1);
            }
            else
            {
                avltree.insert(ws);
                bstree.insert(ws);
                ws.updateCount(1);
            }
            avltree.traverse((w)->{
                return System.out.printf("%-10s%d%n",ws.getWord(), ws.getCount());
            });
        }
        System.out.printf("-----------------------------------\n\n");   
       }   
       
       
       Scanner inFile4  = new Scanner(new FileReader(args[0]));  
       while(inFile.hasNext())
       {
           String testerfile = inFile4.nextLine();
           AVLTree avltree = new AVLTree<WordStat>();
           avltree.insert(testerfile);
           BSTree bstree = new BSTree<WordStat>();
           bstree.insert(testerfile);          
           
        System.out.printf("Table 4:AVL Tree [%s]\n",args[0]);
        System.out.printf("In-order Traversal\n");
        System.out.printf("===================================\n");
        System.out.printf("Word     Frequency\n");
        System.out.printf("-----------------------------------\n"); 
        int count = 0;
        while(inFile.hasNext())
        {
            String word = inFile.next();
            WordStat ws = new WordStat(word.toUpperCase(), count);
            if(avltree.inTree(ws))
            {
                avltree.retrieve(ws).updateCount(1);
                bstree.retrieve(ws).updateCount(1);
            }
            else
            {
                avltree.insert(ws);
                bstree.insert(ws);
                ws.updateCount(1);
            }
            avltree.traverse((w)->{
                return System.out.printf("%-10s%d%n",ws.getWord(), ws.getCount());
            });
        }
        System.out.printf("-----------------------------------\n\n");   
       }  
       
      
       Scanner inFile5  = new Scanner(new FileReader(args[0]));  
       while(inFile.hasNext())
       {
           String testerfile = inFile5.nextLine();
           AVLTree avltree = new AVLTree<WordStat>();
           avltree.insert(testerfile);
           BSTree bstree = new BSTree<WordStat>();
           bstree.insert(testerfile);          
           
        System.out.printf("Table 5:Number of Nodes vs Height\n");
        System.out.printf("Using Data in [%s]\n",args[0]);
        System.out.printf("===================================\n");
        System.out.printf("Tree     # Nodes     Height\n");
        System.out.printf("-----------------------------------\n");
        int count = 0;
        while(inFile.hasNext())
        {
            String word = inFile.next();
            WordStat ws = new WordStat(word.toUpperCase(), count);
            if(avltree.inTree(ws))
            {
                avltree.retrieve(ws).updateCount(1);
                bstree.retrieve(ws).updateCount(1);
            }
            else
            {
                avltree.insert(ws);
                bstree.insert(ws);
                ws.updateCount(1);
            }
            avltree.traverse((w)->{
                return System.out.printf("%-10s%d%n",ws.getWord(), ws.getCount());
            });
        }
        System.out.printf("-----------------------------------\n\n");   
       }  


       Scanner inFile6  = new Scanner(new FileReader(args[0]));  
       while(inFile.hasNext())
       {
           String testerfile = inFile6.nextLine();
           AVLTree avltree = new AVLTree<WordStat>();
           avltree.insert(testerfile);
           BSTree bstree = new BSTree<WordStat>();
           bstree.insert(testerfile);          
           
        System.out.printf("Table 6:Total Number of Nodes Accessed\n");
       System.out.printf("Searching for all the Words in [%s]\n",args[0]);
       System.out.printf("===================================\n");
       System.out.printf("Word          Frequency\n");
       System.out.printf("-----------------------------------\n");
        int count = 0;
        while(inFile.hasNext())
        {
            String word = inFile.next();
            WordStat ws = new WordStat(word.toUpperCase(), count);
            if(avltree.inTree(ws))
            {
                avltree.retrieve(ws).updateCount(1);
                bstree.retrieve(ws).updateCount(1);
            }
            else
            {                
                avltree.insert(ws);
                bstree.insert(ws);
                ws.updateCount(1);
            }           
            avltree.traverse((w)->{               
                return System.out.printf("%-10s%d%n",ws.getWord(), ws.getCount());
            });
        }
        System.out.printf("-----------------------------------\n\n");   
       }         
       //close file
       inFile.close(); 
       }    //catch exception if the file requested isn't found
            catch(FileNotFoundException e)
       {    //print error message
           System.out.printf("ERROR: File not found.\n\n");
       }
    }
}