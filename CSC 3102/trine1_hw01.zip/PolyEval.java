package polynomialdemo;
/**
 * Describes a univariate polynomial and basic operations on it.
 * @author Trine1
 * @since 1/4/17
 */
public interface PolyEval 
{       
    /**
     * Evaluates this polynomial at the specified point using the
     * Horner's evaluation method.
     * @param x the point at which this polynomial is to be evaluated.
     * @return the value of the polynomial at the specified point.
     */
    double hornerEval(double x);
    
    /**
     * Evaluates this polynomial at the specified point using a naive
     * evaluation method.
     * @param x the point at which this polynomial is to be evaluated
     * @return the value of the polynomial at the specified point
     */
    double naiveEval(double x);
    
    /**
     * Gives the degree of this polynomial.
     * @return the degree of this polynomial
     */
    int degree();
    
    /**
     * Gives a string representation of this polynomial in descending powers
     * as an array of its coefficients.
     * @return a string representation of this polynomial as an array
     */
   String toString();   
}