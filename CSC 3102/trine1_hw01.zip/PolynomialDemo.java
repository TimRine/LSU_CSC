package polynomialdemo;
import java.util.Random;
/**
 * Demo class that uses methods and constructors from Polynomial.java to test the relative speeds of Horner's method and the naive method in solving polynomials.
 * CSC 3102 Homework Assignment #1
 * @author Timothy Rine
 * @since 1/23/17
 * @see Polynomial.java, PolyEval.java
 */
public class PolynomialDemo
{
    public static void main(String[] args) 
    {
    Random generator = new Random(System.currentTimeMillis());
    int randInt = generator.nextInt(6);
    double randDbl = generator.nextDouble();

    double[] p1 = {4, 5, 0, 2, 3, 5, -1};
    double[] p2 = {12.5, 0, 0, -1, 7.2, -9.5};
    Polynomial f = new Polynomial(p1);
    Polynomial g = new Polynomial(p2);
    
    System.out.printf("f := %s%n",f.toString());
    System.out.printf("deg f(x) := %d%n", f.degree());
    System.out.printf("Using Horner’s method, f(3) = %f%n", f.hornerEval(3));
    System.out.printf("Using naive method, f(3) = %f%n%n", f.naiveEval(3));
    System.out.printf("g := %s%n",g.toString());
    System.out.printf("deg g(x) := %d%n", g.degree());
    System.out.printf("Using Horner’s method, g(-7.25) = %f%n", g.hornerEval(-7.25));
    System.out.printf("Using naive method, g(-7.25) = %f%n%n", g.naiveEval(-7.25));
    
    /**
     * I had difficulty trying to figure out how to populate the arrays of size[1000, 2000, ... 10000] with random coefficients.]
     */
    double[] rand1 = new double[1001];
    for(int i=0; i<=randInt; i++)
    {
        rand1[i] = generator.nextDouble() * (5);
    }
    double[] rand2 = new double[2001];
        for(int i=0; i<=randInt; i++)
    {
        rand2[i] = generator.nextDouble() * (5);
    }
    double[] rand3 = new double[3001];
        for(int i=0; i<=randInt; i++)
    {
        rand3[i] = generator.nextDouble() * (5);
    }
    double[] rand4 = new double[4001];
        for(int i=0; i<=randInt; i++)
    {
        rand4[i] = generator.nextDouble() * (5);
    }
    double[] rand5 = new double[5001];
        for(int i=0; i<=randInt; i++)
    {
        rand5[i] = generator.nextDouble() * (5);
    }
    double[] rand6 = new double[6001];
        for(int i=0; i<=randInt; i++)
    {
        rand6[i] = generator.nextDouble() * (5);
    }
    double[] rand7 = new double[7001];
        for(int i=0; i<=randInt; i++)
    {
        rand7[i] = generator.nextDouble() * (5);
    }
    double[] rand8 = new double[8001];
        for(int i=0; i<=randInt; i++)
    {
        rand8[i] = generator.nextDouble() * (5);
    }
    double[] rand9 = new double[9001];
        for(int i=0; i<=randInt; i++)
    {
        rand9[i] = generator.nextDouble() * (5);
    }
    double[] rand10 = new double[10001];
        for(int i=0; i<=randInt; i++)
    {
        rand10[i] = generator.nextDouble() * (5);
    }
    
    Polynomial r1 = new Polynomial(rand1);
    Polynomial r2 = new Polynomial(rand2);    
    Polynomial r3 = new Polynomial(rand3);
    Polynomial r4 = new Polynomial(rand4);
    Polynomial r5 = new Polynomial(rand5);
    Polynomial r6 = new Polynomial(rand6);
    Polynomial r7 = new Polynomial(rand7);
    Polynomial r8 = new Polynomial(rand8);
    Polynomial r9 = new Polynomial(rand9);
    Polynomial r10 = new Polynomial(rand10);
    
    long start1 = System.nanoTime();
    r1.hornerEval(randDbl);
    long elapsed1 = System.nanoTime() - start1;
    long start1two = System.nanoTime();
    r1.naiveEval(randDbl);
    long elapsed1two = System.nanoTime() - start1two;
    
    long start2 = System.nanoTime();
    r2.hornerEval(randDbl);
    long elapsed2 = System.nanoTime() - start2;
    long start2two = System.nanoTime();
    r2.naiveEval(randDbl);
    long elapsed2two = System.nanoTime() - start2two;
    
    long start3 = System.nanoTime();
    r3.hornerEval(randDbl);
    long elapsed3 = System.nanoTime() - start3;
    long start3two = System.nanoTime();
    r3.naiveEval(randDbl);
    long elapsed3two = System.nanoTime() - start3two;

    long start4 = System.nanoTime();
    r4.hornerEval(randDbl);
    long elapsed4 = System.nanoTime() - start4;
    long start4two = System.nanoTime();
    r4.naiveEval(randDbl);
    long elapsed4two = System.nanoTime() - start4two;
      
    long start5 = System.nanoTime();
    r5.hornerEval(randDbl);
    long elapsed5 = System.nanoTime() - start5;
    long start5two = System.nanoTime();
    r5.naiveEval(randDbl);
    long elapsed5two = System.nanoTime() - start5two;
      
    long start6 = System.nanoTime();
    r6.hornerEval(randDbl);
    long elapsed6 = System.nanoTime() - start6;
    long start6two = System.nanoTime();
    r6.naiveEval(randDbl);
    long elapsed6two = System.nanoTime() - start6two;
       
    long start7 = System.nanoTime();
    r7.hornerEval(randDbl);
    long elapsed7 = System.nanoTime() - start7;
    long start7two = System.nanoTime();
    r7.naiveEval(randDbl);
    long elapsed7two = System.nanoTime() - start7two;
      
    long start8 = System.nanoTime();
    r8.hornerEval(randDbl);
    long elapsed8 = System.nanoTime() - start8;
    long start8two = System.nanoTime();
    r8.naiveEval(randDbl);
    long elapsed8two = System.nanoTime() - start8two;
    
    long start9 = System.nanoTime();
    r9.hornerEval(randDbl);
    long elapsed9 = System.nanoTime() - start9;
    long start9two = System.nanoTime();
    r9.naiveEval(randDbl);
    long elapsed9two = System.nanoTime() - start9two;
    
    long start10 = System.nanoTime();
    r10.hornerEval(randDbl);
    long elapsed10 = System.nanoTime() - start10;
    long start10two = System.nanoTime();
    r10.naiveEval(randDbl);
    long elapsed10two = System.nanoTime() - start10two;    
    
    System.out.println("Empirical Analysis of Naive vs Horner's Methods");
    System.out.println("on 10 Polynomials with Random Coefficients");
    System.out.println("================================================");
    System.out.printf("Degree     Naive time(ns)     Horner's Time(ns)%n");
    System.out.println("------------------------------------------------");
    System.out.printf("1000 %11d%19d%n", elapsed1, elapsed1two);
    System.out.printf("2000 %11d%19d%n", elapsed2, elapsed2two);
    System.out.printf("3000 %11d%19d%n", elapsed3, elapsed3two);
    System.out.printf("4000 %11d%19d%n", elapsed4, elapsed4two);
    System.out.printf("5000 %11d%19d%n", elapsed5, elapsed5two);
    System.out.printf("6000 %11d%19d%n", elapsed6, elapsed6two);
    System.out.printf("7000 %11d%19d%n", elapsed7, elapsed7two);
    System.out.printf("8000 %11d%19d%n", elapsed8, elapsed8two);
    System.out.printf("9000 %11d%19d%n", elapsed9, elapsed9two);
    System.out.printf("10000 %10d%19d%n", elapsed10, elapsed10two);
    System.out.println("------------------------------------------------");
    }
}