package polynomialdemo;
/**
 * Class that defines constructors and methods to be used in PolynomialDemo.java
 * CSC 3102 Homework Assignment #1
 * @author Timothy Rine
 * @since 1/23/17
 * @see PolynomialDemo.java, PolyEval.java
 */
public class Polynomial implements PolyEval
{
     private double[] coeffs;
        
    /**
     * Creates the polynomial 0
     */
    public Polynomial()
    {
     coeffs[0] = 0;
    }
    
    /**
     * Creates a polynomial with the specified coefficients
     * @param c the coefficients in descending powers of this polynomial
     */
    public Polynomial(double[] c)
    {
        coeffs = c;
    }
    
    /**
     * Evaluates this polynomial at the specified point using the
     * Horner's evaluation method.
     * @param x the point at which this polynomial is to be evaluated.
     * @return the value of the polynomial at the specified point.
     */
    @Override
    public double hornerEval(double x)
    {
        double answer = coeffs[0];
        for(int i = 1; i <= degree(); i++)
            {
                answer = coeffs[i] + (x * answer);
            }
        return answer;
    }
    
    /**
     * Evaluates this polynomial at the specified point using a naive
     * evaluation method.
     * @param x the point at which this polynomial is to be evaluated
     * @return the value of the polynomial at the specified point
     */
    @Override
    public double naiveEval(double x)
    {
        double a = coeffs[degree()];
        double b = 0;
            for(int i = degree()-1; i >= 0; i--)
            {
            b++;
            double c = 1;
            for(int t = 1; t <= b; t++)               
                {
                c*=x;
                }                
            a += coeffs[i]*c;
            }
            return a;
    }
    
    /**
     * Gives the degree of this polynomial.
     * @return the degree of this polynomial
     */
    @Override
    public int degree()
    {
        int deg = 0;
        for (int i = 0; i < coeffs.length; i++)
        {
            if (coeffs[i] != 0) deg = i;
        }
        return deg;
    }
    
    /**
     * Gives a string representation of this polynomial in descending powers
     * as an array of its coefficients.
     * @return a string representation of this polynomial as an array 
     */
    @Override
    public String toString()
    {
    String s="[";
    for(int i=0; i<=degree(); i++)
    {
      if (i==0) 
      {
          s+= "";
      }
      else if (i!=0) 
      {
          s+=", ";
      }
      s+=coeffs[i];
    }
    return s+"]";
    }
}