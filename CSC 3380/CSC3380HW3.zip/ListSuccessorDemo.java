package listsuccessordemo;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.*;
/**
 * This program takes user-inputted integers to create an ArrayList and outputs the successor. 
 * CSC 3380
 * @author Timothy Rine
 * LSUID: 895510378
 * @since March 3rd, 2017
 */
public class ListSuccessorDemo
{
    public static void main(String[] args) 
    {   
        //Creates the ArrayList
        ArrayList<Integer> list = new ArrayList();
        //Creates the Scanner object
        Scanner next = new Scanner(System.in);
        //Prints a statement asking the user for an integer input
        System.out.printf("Please enter the integers of the array.%n");
        //Starts a while loop for variable user input
        while (next.hasNext())
        {
        //Beginning of the try-catch statement for finding bad user input
        try {
            //Continue if there is a user-inputted integer
            if (next.hasNextInt())
            //Add the integer to the ArrayList that was created
            list.add(next.nextInt());
            //Otherwise end the loop
            else
                break;
            }
        //If the user gives bad input, throw the exception message
        catch (InputMismatchException e)
                {
                //Output to be given if user inputs bad values
                System.out.print(e.getMessage()); 
                //End
                break;
                }
        }
        //Print the ArrayList that the user inputted
        System.out.println("ArrayList contains: "+ list.toString());
        //Begin the loop to determine the successor. Loop goes from 0 to n-1
        for(int i=0; i<(list.size()-1); i++)
        {
            //Creates the int variable element which is equal to the last element of the ArrayList
            int element = (list.get(list.size()-1)); 
            //Begins an if-statement to determine the value to increment. Enters the subloop if the last value of the ArrayList is not equal to 9
            if(list.get(list.size()-1)!=9)
            {                 
                //Increments the last value of the ArrayList by 1 
                list.set(list.size()-1, element+1); 
                //Ends the loop
                break;                                              
            }
            //If the last value in the ArrayList is equal to 9, continue
            else
            {
                //Sets the last value in the ArrayList to 0
                list.set(list.size()-1, 0);
                if(list.get(list.size()-2)!=9)
                {
                    //Increments the next value in the ArrayList by 1 if it is not equal to 9
                    list.set(list.size()-2, list.get(list.size()-2)+1);
                    break;
                }
                else
                {
                //Set the 2nd to last value to 0
                list.set(list.size()-2, 0);
                //Increment the 3rd to last value by 1
                list.set(list.size()-3, list.get(list.size()-3)+1);
                break;
                }
            }
        }
        //Print the successor of the original array.
        System.out.println("The successor of this array equals: "+ list.toString());
    }
}